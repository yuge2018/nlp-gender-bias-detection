# P4 统一评测与复现

本目录是第 8 题（CORGI-PM 中文文本性别偏见二分类）中 **P4** 的独立交付物：
契约检查、统一指标、多种子汇总、复现记录与结果表生成。

评测器**只依赖 Python 标准库**（json / csv / hashlib / statistics / unittest），
不导入任何模型实现或 GPU 库；`matplotlib` 只用于可选的结果图。

## 快速开始

在 `p4-evaluation/` 目录下：

```sh
python -m src.evaluation --mock --output-dir runs/p4-smoke
python -m unittest discover -s tests -v
```

第一条命令会生成 `fixtures/`（mock 数据包 + 2 方法 × 3 seed 的 mock run），
评测全部 6 个 run 并输出对比表；第二条命令运行 21 个测试。

> 所有 mock 结果都带 `is_mock=true`，`comparison.md` 顶部有醒目提示，
> 正式比较默认拒绝 mock（需显式 `--allow-mock`）。

## 目录结构

```
p4-evaluation/
├── src/
│   ├── common/contracts.py      共享契约常量 + JSONL/哈希最小参考实现（P4 维护）
│   └── evaluation/
│       ├── __main__.py          CLI：evaluate / compare / --mock
│       ├── metrics.py           混淆矩阵、P/R/F1、Macro-F1
│       ├── checks.py            数据包、run 元信息、预测文件校验
│       ├── aggregate.py         多种子均值 ± 样本标准差
│       ├── fixtures.py          内置 mock 数据与 run（可重复生成）
│       └── plot_results.py      Macro-F1 柱状图
├── configs/evaluation/default.json   评测口径
├── fixtures/                    mock 数据包与 mock run（运行后生成）
├── runs/p4-smoke/               mock 冒烟输出（comparison.csv 等）
├── reports/sections/P4.md       本人报告片段
├── reports/figures/P4/          本人图表
├── reports/results/             正式结果目录（真实 run 才写入）
├── requirements/p4.txt
└── tests/p4/                    21 个测试
```

## CLI

```sh
# 1) 评测单个 run：metrics.json 写回 run 目录，可选另存
python -m src.evaluation evaluate \
  --data-dir data/processed/corgi-official-v1 --split test \
  --run-dir runs/baseline-s42-test [--output-dir reports/results]

# 2) 多个 run 对比：生成 comparison.csv / aggregate.csv / comparison.md
python -m src.evaluation compare \
  --run-dirs runs/baseline-s42-test runs/baseline-s43-test \
             runs/improved-s42-test runs/improved-s43-test \
  --data-dir data/processed/corgi-official-v1 --output-dir reports/results

# 3) 开发联调（合成数据，禁止用于结论）
python -m src.evaluation --mock --output-dir runs/p4-smoke
```

退出码：`0` 成功；`2` 参数/契约/数据错误（stderr 指明路径、行号或 ID）；`1` 其他运行失败。

## 契约检查清单

数据包（`--data-dir`）：

- `manifest.json` 必需字段齐全、`schema_version` 受支持、`is_mock` 为布尔；
- `files` 中每个文件的 SHA256 与行数和实际字节一致（篡改立即报错）；
- dev/test 文本与金标 ID 一一对应、顺序一致、无重复、无空文本；
- 金标 label 必须是真正的整数 0/1（bool 会被拒绝）。

run（`--run-dir`）：

- `run_metadata.json` 必需字段齐全，`is_mock` 与 manifest 一致；
- `dataset_manifest_sha256` 等于数据包 manifest 原始字节的 SHA256；
- `split`、`seed`、`threshold∈[0,1]` 合法；
- 预测行数 = 金标行数，ID 顺序逐行一致；
- `label` 为整数 0/1，`score` 有限且在 `[0,1]`；
- `label == int(score >= threshold)`，防止事后改标签或换阈值。

compare 额外检查：所有 run 的数据 hash、split、mock 标记必须一致；真实比较拒绝 mock。

## 输出文件

`metrics.json`（写回 run 目录）：

```
schema_version, is_mock, method, split, seed, threshold, n,
accuracy, macro_f1, positive_precision, positive_recall, positive_f1,
negative_f1, confusion_matrix, dataset_manifest_sha256,
predictions_sha256, run_dir, created_at, evaluator
```

`confusion_matrix` 行是真值 0/1、列是预测 0/1，即 `[[TN, FP], [FN, TP]]`。

`comparison.csv`：每次 run 一行，含 method、data_hash、split、seed、is_mock、
各指标、混淆矩阵四格、run 路径与预测文件 hash。
`aggregate.csv`：按方法汇总，保留 `seeds` 列表，输出 `mean` 与样本标准差 `std`；
单次 run 的 std 为 null。
`environment.json`：Python/平台/CPU、git commit、命令行、数据 hash。
`reproduction.json`：命令、数据包、每个 run 的预测 hash 与产物清单。

## 接真实 run（D7）

1. 用 P1 的 `data/processed/corgi-official-v1`（或 clean 版，不能混用）作为 `--data-dir`；
2. 把 P2/P3 的 run 目录传给 `--run-dirs`，确认每个 run 的 `is_mock=false`；
3. 运行 `compare`，检查 `comparison.csv` 的 data_hash 列全部相同；
4. 换目录（或干净环境）重跑同一命令，核对 `reproduction.json` 与 `metrics.json` 一致。

## 测试覆盖

- 手算混淆矩阵与 F1 一致；全对、全错、零分母；
- 缺行、重复 ID、乱序、NaN、越界分数、bool 标签、阈值不符；
- mock 标记不一致、数据 hash 不一致、manifest 被篡改；
- compare 拒绝 mock、拒绝混合 split；
- CLI 冒烟产物完整、篡改后退出码为 2。

## 已知限制

- fixtures 为合成数据，mock 分数只用于验证流程，不能写进报告主表；
- 评测器不负责阈值调优，阈值只从 run 元信息读取；
- 不计算分组指标（P5 负责），不生成挑战集；
- `git_commit` 在非 git 目录下为 null。
